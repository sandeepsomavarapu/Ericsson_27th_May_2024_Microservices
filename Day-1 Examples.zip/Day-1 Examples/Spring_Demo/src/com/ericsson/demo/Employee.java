package com.ericsson.demo;

public class Employee {
	private int empId;
	private String empName;
	private float empSal;
	private String empDesg;

	public Employee() {
		System.out.println("Default Constructor");
	}

	public Employee(int empId, String empName, float empSal, String empDesg) {
		super();
		System.out.println("param constructor");
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

}
