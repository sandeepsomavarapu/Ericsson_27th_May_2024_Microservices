package com.ericsson.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	public static void main(String[] args) {
//	Employee emp=new Employee();
		Resource resource = new ClassPathResource("springconfig.xml");
		BeanFactory factory = new XmlBeanFactory(resource);

		
		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp);
//		emp.setEmpId(123);
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		
		
		Employee emp1 = (Employee) factory.getBean("emp1");
		System.out.println(emp1);
		System.out.println(emp1.getEmpId());
		System.out.println(emp1.getEmpName());
		
	}
}
