package com.ericsson.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Test {
	public static void main(String[] args) {
//	Employee emp=new Employee();
//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
		
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");
		
		Employee emp = (Employee) factory.getBean("emp");
		System.out.println(emp);
		System.out.println(emp.getAddress());

//		Employee emp1 = (Employee) factory.getBean("emp");
//		System.out.println(emp1);

	}
}
