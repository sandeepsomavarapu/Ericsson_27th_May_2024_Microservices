package com.ericsson.jpademo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ericsson_emps")
public class Employee {//ORM		//employee-->empid,empname,empsal,enpdesg
	@Id
	@Column(name="eid",length=15)
	private int empId;
	@Column(name="ename",length=15)
	private String empName;
	private int empSal;
	@Column(name="designation")
	private String empDesg;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empName, int empSal, String empDesg) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

}
