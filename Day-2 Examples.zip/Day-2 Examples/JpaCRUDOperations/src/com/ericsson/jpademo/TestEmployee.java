package com.ericsson.jpademo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {
		// ORM
		Employee emp = new Employee(123, "mahesh", 23456, "hr");

		// persist()-->insert,merge()-->update,remove()-->delete,find()-->select

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("mysql");
		EntityManager entityManager = factory.createEntityManager();

		entityManager.getTransaction().begin();
		entityManager.persist(emp);// ORM
		entityManager.getTransaction().commit();
		System.out.println("inserted !!! we are feeling hungry leave us!!");

	}

}
