package com.ericsson.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductRestUsingJpaHIbernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductRestUsingJpaHIbernateApplication.class, args);
	}

}
