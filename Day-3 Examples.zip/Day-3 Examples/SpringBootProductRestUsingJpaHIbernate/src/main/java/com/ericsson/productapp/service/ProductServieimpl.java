package com.ericsson.productapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServieimpl implements ProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public String addProduct(Product product) {

		return repo.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		
		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return repo.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetweenTheRange(int intialPrice, int finalPrice) {

		return repo.getAllProductsBetweenTheRange(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return repo.getAllProductsByCategory(productCategory);
	}

}
