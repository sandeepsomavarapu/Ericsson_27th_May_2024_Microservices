package com.ericsson.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {

	@GetMapping("/hi") // http://localhost:8080/products/hi
	public String sayHello() {
		return "Hello everyone !!! am from product controller ";
	}

	@GetMapping("/listProducts") // http://localhost:8080/products/listProducts
	public List<Product> productsList() {
		List<Product> products = new ArrayList<Product>();
		products.add(new Product(123, "samsung", 23000, 20, "electronics"));
		products.add(new Product(124, "dell", 54690, 10, "electronics"));
		products.add(new Product(125, "lenovo", 23000, 80, "electronics"));
		products.add(new Product(126, "mi", 28000, 20, "electronics"));
		products.add(new Product(127, "apple", 13000, 120, "electronics"));
		products.add(new Product(128, "samsung", 83000, 50, "electronics"));

		return products;
	}

}
