package com.ericsson.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {
	static List<Product> products = new ArrayList<Product>();

	static {
		products.add(new Product(123, "samsung", 23000, 20, "electronics"));
		products.add(new Product(124, "dell", 54690, 10, "electronics"));
		products.add(new Product(125, "lenovo", 23000, 80, "electronics"));
		products.add(new Product(126, "mi", 28000, 20, "electronics"));
		products.add(new Product(127, "apple", 13000, 120, "electronics"));
		products.add(new Product(128, "samsung", 83000, 50, "electronics"));
	}

	@GetMapping("/hi") // http://localhost:8080/products/hi
	public String sayHello() {
		return "Hello everyone !!! am from product controller ";
	}

	@GetMapping("/listProducts") // http://localhost:8080/products/listProducts
	public List<Product> productsList() {

		return products;
	}

	@PostMapping("/insertProduct") // http://localhost:8080/products/insertProduct
	public List<Product> addProduct(@RequestBody Product product) {
		products.add(product);
		return products;
	}

	@GetMapping("/getProduct/{pid}") // http://localhost:8080/products/getProduct/123
	public Product getProduct(@PathVariable("pid") int productId) {
		Optional<Product> product1 = products.parallelStream().filter(product -> product.getProductId() == productId)
				.findAny();

		return product1.get();
	}
	@DeleteMapping("/deleteProduct/{pid}") // http://localhost:8080/products/deleteProduct/123
	public String removeProduct(@PathVariable("pid") int productId) {
		Optional<Product> product1 = products.parallelStream().filter(product -> product.getProductId() == productId)
				.findAny();
		products.remove(product1.get());
		
		return "Product Removed Successfully" ;
	}
}
