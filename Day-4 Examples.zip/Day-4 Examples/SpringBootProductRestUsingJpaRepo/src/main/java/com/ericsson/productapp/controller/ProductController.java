package com.ericsson.productapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/insertProduct") // http://localhost:2123/products/insertProduct
	public String addProduct(@RequestBody @Validated Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/mergeProduct") // http://localhost:2123/products/mergeProduct
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteProduct/{pid}") // http://localhost:2123/products/deleteProduct/123
	public String removeProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/getProduct/{pid}") // http://localhost:2123/products/getProduct/123
	public Product getProduct(@PathVariable("pid") int productId) throws ProductNotFound {
		return service.getProduct(productId);
	}

	@GetMapping("/listProducts") // http://localhost:2123/products/listProducts
	public List<Product> productsList() {

		return service.getAllProducts();
	}

	@GetMapping("/getProducts/{ip}/{fp}") // http://localhost:2123/products/getProducts/1000/2000
	public List<Product> productsListBetweenPriceRange(@PathVariable("ip") int intialPrice,
			@PathVariable("fp") int finalPrice) {

		return service.getAllProductsBetweenTheRange(intialPrice, finalPrice);
	}

	@GetMapping("/getProductsByCategory/{cat}") // http://localhost:2123/products/getProductsByCategory/elctronics
	public List<Product> productsList(@PathVariable("cat") String category) {

		return service.getAllProductsByCategory(category);
	}
//	@ExceptionHandler(ProductNotFound.class)	
//	@ResponseStatus(reason = "ProductId is Invalid",code = HttpStatus.NOT_FOUND)
//	public void handleException()
//	{
//		
//	}
	
}
