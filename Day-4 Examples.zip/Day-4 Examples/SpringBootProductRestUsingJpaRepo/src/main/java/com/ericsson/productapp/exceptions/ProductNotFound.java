package com.ericsson.productapp.exceptions;

public class ProductNotFound extends RuntimeException {
	public ProductNotFound(String message) {
		super(message);
	}
}
