package com.ericsson.productapp.service;

import java.util.List;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.exceptions.ProductNotFound;

public interface ProductService {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId);

	public abstract Product getProduct(int productId) throws ProductNotFound;

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getAllProductsBetweenTheRange(int intialPrice, int finalPrice);

	public abstract List<Product> getAllProductsByCategory(String productCategory);
}
