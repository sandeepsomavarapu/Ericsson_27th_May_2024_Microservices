package com.ericsson.productapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.productapp.entity.Product;
import com.ericsson.productapp.exceptions.ProductNotFound;
import com.ericsson.productapp.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServieimpl implements ProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public String addProduct(Product product) {
		Product pro = repo.save(product);
		if (pro != null)
			return "product saved ....";
		else
			return "something went wrong";
	}

	@Override
	public String updateProduct(Product product) {
		Product pro = repo.save(product);
		if (pro != null)
			return "product updated ....";
		else
			return "something went wrong";
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "product deleted ...";
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product> pro = repo.findById(productId);
		if (pro.isPresent())
			return pro.get();
		else
			throw new ProductNotFound("Invalid ProductID .....");
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsBetweenTheRange(int intialPrice, int finalPrice) {

		return repo.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return repo.findByProductCategory(productCategory);
	}

}
